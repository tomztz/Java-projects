import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.Collections;
/* SELF ASSESSMENT 

1. readDictionary
- I have the correct method definition [Mark out of 5:5]
- Comment: Yes,I want the function to return an arraylist of the words in the files, so it's defined as public static ArrayList<String> readDictionary().
- My method reads the words from the "words.txt" file. [Mark out of 5:5]
- Comment: Yes,the "File dictionary = new File("words.txt");" reads in the file, and if the file is not readed an error will be displayed, which didn't after running.
- It returns the contents from "words.txt" in a String array or an ArrayList. [Mark out of 5:5]
- Comment: Yes, every time It reaches the next line,the string(word) will be added to the arraylist, until there are nothing left, the arraylist finally returns.

2. readWordList
- I have the correct method definition [Mark out of 5:5]
- Comment: Yes, I want the method returns an ArrayList and takes a string which the user types, and an empty arrayList as parameters, thus it's defined as
"public static ArrayList<String> readWordList(String word, ArrayList<String> wordsArray)".
- My method reads the words provided (which are separated by commas, saves them to an array or ArrayList of String references and returns it. [Mark out of 5:5]
- Comment: Yes, I converted the String into a char array, and every time each character is added to make up the string unless it reaches a comma or the final word,which would
add the string into arrayList then reset the string to empty.

3. isUniqueList
- I have the correct method definition [Mark out of 5:5]
- Comment: Yes,I want it to return weather the word is Unique is true or false, so I set the return type into a boolean, and it takes in the arrayList of words,
so it's defined as,"public static boolean isUniqueList(ArrayList<String> wordsArray)".
- My method compares each word in the array with the rest of the words in the list. [Mark out of 5:5]
- Comment: Yes,the nested for loop allows the first string to compare with the rest of the strings, the second to the rest etc.
- Exits the loop when a non-unique word is found. [Mark out of 5:5]
- Comment: Yes, whenever the two strings are equal it returns false which exits out of the function.
- Returns true is all the words are unique and false otherwise. [Mark out of 5:5]
- Comment: Yes, when exiting the loops (all words are unique)it returns true.

4. isEnglishWord
- I have the correct method definition [Mark out of 5:5]
- Comment: Yes,I want it to return weather the word is in file is true or false, so I set the return type into a boolean, and it takes in a single word,
so it's defined as"public static boolean isEnglishWord(String word)".
- My method uses the binarySearch method in Arrays library class. [Mark out of 3:3]
- Comment: Yes,I used collections.binarysearch to search if the word is in the arraylist made from the file.
- Returns true if the binarySearch method return a value >= 0, otherwise false is returned. [Mark out of 2:2]
- Comment: Yes,the if conditions says if index<=0 then return false, and returning true otherwise.

5. isDifferentByOne
- I have the correct method definition [Mark out of 5:5]
- Comment: Yes,I want it to return weather the word is differ by 1 letter is true or false, so I set the return type into a boolean, and it takes in a two words,
so it's defined as"public static boolean isDifferentByOne(String word1, String word2)".
- My method loops through the length of a words comparing characters at the same position in both words searching for one difference. [Mark out of 10:10]
- Comment: Yes, I turned both words into two chars arrays, and comparing each letter by a loop,if it differs it's adding 1 to var count,if count is not 1 than
it's differ more than 1 letter,thus it returns false, but return true otherwise.

6. isWordChain
- I have the correct method definition [Mark out of 5:5]
- Comment: Yes,I want it to return weather the word chain is valid  is true or false,so I set the return type into a boolean,and it takes an ArrayList, so it's defined as
"public static boolean isWordChain(ArrayList<String> wordsArray)".
- My method calls isUniqueList, isEnglishWord and isDifferentByOne methods and prints the appropriate message [Mark out of 10:10]
- Comment: Yes,it first calls isUniqueList, if it is not unique it's returning false, if it is it's calling isEnglishWord if it's not an english word it's returning false,
same for isDifferentByOne, only all three returns true, returns true for the function.

7. main
- Reads all the words from file words.txt into an array or an ArrayList using the any of teh Java.IO classes covered in lectures [Mark out of 10:9]
- Comment: Yes, calling the function reads the file, and IO is imperted.
- Asks the user for input and calls isWordChain [Mark out of 5:5]
- Comment: Yes, a scanner is used to ask the users imput until an emty list is entered.

 Total Mark out of 100 (Add all the previous marks):99
*/


public class WordsLinkPuzzleGame {

	public static ArrayList<String> readDictionary() {
		ArrayList<String> dictionaryArray = new ArrayList<String>();
		try {

			File dictionary = new File("words.txt");
			Scanner dicScanner = new Scanner(dictionary);
			while (dicScanner.hasNextLine()) {
				String data = dicScanner.nextLine();
				dictionaryArray.add(data);

			}

			return dictionaryArray;

		} catch (FileNotFoundException e) {
			System.out.println("An error occurred.");

			dictionaryArray.clear();
			return dictionaryArray;
		}

	}

	public static ArrayList<String> readWordList(String word, ArrayList<String> wordsArray) {
		char[] wordArray = word.toCharArray();
		String wordVar = "";
		for (int i = 0; i < wordArray.length; i++) {

			if (i == wordArray.length - 1) {
				wordVar = wordVar + wordArray[i];
				wordsArray.add(wordVar);
			}
			if (wordArray[i] == ',') {
				wordsArray.add(wordVar);
				wordVar = "";
			} else {
				wordVar = wordVar + wordArray[i];
			}
		}

		return wordsArray;
	}

	public static boolean isUniqueList(ArrayList<String> wordsArray) {
		for (int i = 0; i < wordsArray.size(); i++) {
			for (int j = i + 1; j < wordsArray.size(); j++) {
				if (wordsArray.get(i).equals(wordsArray.get(j))) {

					return false;

				}

			}

		}
		return true;
	}

	public static boolean isEnglishWord(String word) {

		ArrayList<String> dic = readDictionary();

		int index = Collections.binarySearch(dic, word);
		if (index <=0) {
			return false;
		}
		return true;
	}

	public static boolean isDifferentByOne(String word1, String word2) {
		char[] word1Array = word1.toCharArray();
		char[] word2Array = word2.toCharArray();
		int count = 0;
		for (int i = 0; i < word1.length(); i++) {
			if (word1Array[i] != word2Array[i]) {
				count = count + 1;
			}

		}
		if (count != 1) {
			return false;
		}
		return true;
	}

	public static boolean isWordChain(ArrayList<String> wordsArray) {

		if (isUniqueList(wordsArray) == true) {
			for (String word : wordsArray) {
				if (isEnglishWord(word) == false) {
					return false;
				}
			}

			for (int i = 0; i < wordsArray.size() - 1; i++) {
				if (isDifferentByOne(wordsArray.get(i), wordsArray.get(i + 1)) == true) {
					return true;
				}
			}

		}
		return false;
	}

	public static void main(String[] args) {

		readDictionary();
		while (true) {
			ArrayList<String> inputWordsArray = new ArrayList<String>();
			System.out.println("Enter a comma separated list of words (or an empty list to quit):");
			Scanner input = new Scanner(System.in);
			if (!input.hasNext()) {
				break;
			}

			String inputWords = input.next();

			
			if (isWordChain(readWordList(inputWords, inputWordsArray)) == true) {
				System.out.println("Valid chain of words from Lewis Carroll's word-links game.");
			} else {
				System.out.println("Not a valid chain of words from Lewis Carroll's word-links game.");
			}
		}
	}

}
