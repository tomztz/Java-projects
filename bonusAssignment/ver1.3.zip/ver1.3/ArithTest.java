import static org.junit.Assert.*;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.JUnit4;

import java.util.Arrays;

//-------------------------------------------------------------------------
/**
 *  Test class for Arith class.
 *
 *  @version 3.1 15/12/17 11:32:15
 *
 *  @author  Tianze Zhang
 */

@RunWith(JUnit4.class)

public class ArithTest {
    @Test
    public void getValueZero(){
        String[] infixExpression = {"0","!","0"};


    assertEquals("division by 0", 0, Arith.evaluateInfixOrder(infixExpression));
    }
    @Test
    public void validateInfixOrderTrue() {

        String[] infixExpression = {"(", "(", "1", "-", "2", ")", "*", "3", ")", "+", "(", "10",
                "-", "(", "3", "+", "(", "6", "/", "3", ")", ")", ")"};

        assertEquals("Check validate infix expression true.", true, Arith.validateInfixOrder(infixExpression));


    }
    @Test
    public void validateInfixOrderFalse() {

        String[] prefixExpression = {"+", "*", "2", "3", "/", "6","2"};

        assertEquals("Check validate infix expression false.", false, Arith.validateInfixOrder(prefixExpression));


    }
    @Test
    public void validateInfixOrderFalseWithInvalidBracketsAndOp() {

        String[] infixExpression = {"(", "+", ")", "3", "/", "6","2","+","2"};

        assertEquals("Check validate infix expression false.", false, Arith.validateInfixOrder(infixExpression));


    }
    @Test
    public void validateInfixOrderFalseWithNull() {

        String[] infixExpression = {"(", ")"};

        assertEquals("Check validate infix expression false.", false, Arith.validateInfixOrder(infixExpression));


    }
    @Test
    public void validateInfixOrderFalseWithUnbalanceBrackets() {

        String[] infixExpression = {"(", "2","+","2",")",")"};

        assertEquals("Check validate infix expression false.", false, Arith.validateInfixOrder(infixExpression));


    }
    @Test
    public void evaluateInfixOrderTrue() {

        String[] infixExpression = {"(", "(", "1", "-", "2", ")", "*", "3", ")", "+", "(", "10",
                "-", "(", "3", "+", "(", "6", "/", "3", ")", ")", ")"};

        assertEquals("Check evaluate Infix expression true.", 2, Arith.evaluateInfixOrder(infixExpression));


    }
    @Test
    public void convertInfixToPostfixTrue2() {

        String[] infixExpression = {"7", "+", "8", "*", "3", "-", "22"};

        String[]expectedExpression={"7", "8", "3", "*", "22", "-" ,"+"};

        for(int i=0;i<expectedExpression.length;i++) {
            System.out.print(Arith.convertInfixToPostfix(infixExpression)[i]);
            //assertEquals("Check convert Infix to postfix expression true.", expectedExpression[i], Arith.convertInfixToPostfix(infixExpression)[i]);
        }


    }

    @Test
    public void convertInfixToPostfixTrue() {

        String[] infixExpression = {"(","(", "1","-", "2", ")","*", "3",
        ")","+", "(","10","-", "(","3", "+", "(","6", "/", "3",")",")",")"};

        String[] expectedExpression={"1", "2","-","3", "*","10","3","6","3","/", "+", "-", "+"};
        for(int i=0;i<expectedExpression.length;i++) {
            assertEquals("Check convert Infix to postfix expression true.", expectedExpression[i], Arith.convertInfixToPostfix(infixExpression)[i]);
        }

    }

    @Test
    public void convertPostfixToInfixTrue() {

        String[] expectedExpression= {"(","(", "1","-", "2", ")","*", "3",
                ")","+", "(","10","-", "(","3", "+", "(","6", "/", "3",")",")",")"};

        String[] postfixExpression={"1", "2","-","3", "*","10","3","6","3","/", "+", "-", "+"};

        for(int i=0;i<expectedExpression.length;i++) {

            assertEquals("Check convert postfix to infix expression true.", expectedExpression[i], Arith.convertPostfixToInfix(postfixExpression)[i]);
        }

    }
}