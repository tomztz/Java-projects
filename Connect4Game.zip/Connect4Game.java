import java.util.Arrays;
import java.util.List;
import java.util.Scanner;

public class Connect4Game {

  
  public static final int PIECES_CONNECTED_TO_WIN = 4;
  
  private Player[] players = new Player[2];
  
  public Connect4Game() {}
 
  public Connect4Game(Player player1, Player player2) { 
     players[0] = player1;
     players[1] = player2;
  }
  
  public static void main(String[] args) {
 
     Player player1 = new C4HumanPlayer();
     System.out.println("Please choose your disc colour, R (red) or Y(yellow) : ");
     Scanner input = new Scanner(System.in);
     char discColour = input.next().charAt(0);
     player1.setDiscColour(discColour);
     
     System.out.println("Please choose to play with human player(H) or computer(C) : ");
     char type = input.next().charAt(0);     
     Player player2 = null; 
     if (type == 'H') player2 = new C4HumanPlayer();
       else if (type == 'C') player2 = new C4RandomAIPlayer();
     
     player2.setDiscColour(player1.getDiscColour()=='R'?'Y':'R');
     
     Connect4Grid board = new Connect4Grid2DArray();
     board.emptyGrid();
     board.toString();
    
     Player currentPlayer = player1;
     List<Integer> availableColumnsToChoose = Arrays.asList(0,1,2,3,4,5,6);  
     
     while (!board.isGridFull() && !board.didLastPieceConnect4()) {
       int column = currentPlayer.chooseColumn(availableColumnsToChoose);
       if (board.isValidColumn(column)) board.dropPiece(currentPlayer, column);
       if (board.isColumnFull(column))  availableColumnsToChoose.remove(column);
             
       currentPlayer = player2;       
     }
    
     if (board.didLastPieceConnect4()) 
      System.out.println("The winner is " + currentPlayer.getDiscColour());
    
  }

}
