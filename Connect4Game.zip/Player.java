import java.util.List;

public abstract class Player {
  private char discColour;  

  public abstract Integer chooseColumn(List<Integer> availableColumnsToChoose);
  
  public char getDiscColour() {
    return discColour;
  }
  
  public void setDiscColour(char discColour) {
    this.discColour = discColour;
  }

}
