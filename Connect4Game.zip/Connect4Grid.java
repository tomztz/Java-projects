
public interface Connect4Grid {
  public void emptyGrid();
  public String toString();
  public boolean isValidColumn(Integer column);
  public boolean isColumnFull(Integer column);
  public void dropPiece(Player player, Integer column);
  public boolean didLastPieceConnect4();
  public boolean isGridFull(); 

}
