import java.util.Arrays;
import java.util.List;
import java.util.Random;
import java.util.Scanner;

public class C4HumanPlayer extends Player {

  @Override
  public Integer chooseColumn(List<Integer> availableColumnsToChoose) {
   
    System.out.println("The availiable columns to choose are: " + availableColumnsToChoose.toArray().toString());
    System.out.println("Please choose column to drop the disc:");
    Scanner input = new Scanner(System.in);
    int columnNumber = input.nextInt();
    return columnNumber;
  }

}
