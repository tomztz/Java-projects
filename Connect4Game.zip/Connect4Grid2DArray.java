
public class Connect4Grid2DArray implements Connect4Grid {

  private static final int BOARD_ROWS = 6;
  private static final int BOARD_COLUMNS = 7;
  private static final char BLANK = ' ';
  
  private static final char[][] BOARD = new char[BOARD_ROWS][BOARD_COLUMNS];
  
  private int[] lastDropPosition = new int[]{-1,-1};
    
  @Override
  public void emptyGrid() {
    for(int i = 0; i< BOARD_ROWS; i++)
    {
      for (int j = 0; j < BOARD_COLUMNS; j++)
      {
        BOARD[i][j]= BLANK;
      }
    }
  }

  @Override
  public boolean isValidColumn(Integer column) {
    
    if (column >= 0 && column <= 6) return true;
    
    return false;
  }

  @Override
  public boolean isColumnFull(Integer column) {
      if (BOARD[5][column] != BLANK) return true; 
      return false;
  }

  @Override
  public boolean isGridFull() {
    for(int i = 0; i< BOARD_ROWS; i++) 
    {
      for (int j = 0; j < BOARD_COLUMNS; j++)
      {
        if(BOARD[i][j] == BLANK) return false; 
      }
    }
    return true;
  }

  @Override
  public void dropPiece(Player player, Integer column) {
    for(int i = 0; i < BOARD_ROWS; i++)
    {
      if(BOARD[i][column] == BLANK)
      {
        BOARD[i][column]= player.getDiscColour();
        
        lastDropPosition[0] = i;
        lastDropPosition[1] = column;
      }
    }
  }
  
  @Override
  public String toString() {
    
    StringBuilder builder = new StringBuilder();
    for (int row = 0; row < BOARD_ROWS; row++) {
        builder.append("| ");
       for (int col = 0; col < BOARD_COLUMNS; col++) {
          
         builder.append(BOARD[row][col]);
         builder.append(" | ");
       }  
       
       builder.append("\n");  
    }
    
    for (int col = 0; col < BOARD_COLUMNS; col++)
      builder.append("----");
      
      builder.append("\n");
      builder.append("  0 | 1 | 2 | 3 | 4 | 5 | 6");
    
    return builder.toString();
  }
  
  @Override
  public boolean didLastPieceConnect4() {
     int row = lastDropPosition[0];
     int col = lastDropPosition[1];
     char lastDropMark = BOARD[row][col];
     
     int counter = 0;
     
     //check horizontally
     for ( int i = 0 ; i <BOARD_ROWS  ; i++) {
         counter = 0;
         for ( int j = 0 ; j < BOARD_COLUMNS-1 ; j++){
            if ( ( BOARD[i][j] == lastDropMark &&  BOARD[i][j] == BOARD[i][j+1])) counter++;
       
            if (counter == 4) return true;
       
         }
     }
        
     //check vertically
     for ( int j = 0 ; j < BOARD_COLUMNS ; j++){
         counter = 0;
         for ( int i = 0 ;  i < BOARD_ROWS-1 ; i++){
            if ( ( BOARD[i][j] == lastDropMark && BOARD[i][j] == BOARD[i+1][j])) counter++;
            if ( counter == 4) return true;
         }
     }
    
     //check diagonal
     for ( int y = 3 ; y < BOARD_ROWS ; y++){
        counter = 0;
        for ( int x = 0 ; x < 4 ; x++){
             if ((BOARD[y][x] == lastDropMark && BOARD[y][x] == BOARD[y+1][x+1]) && (BOARD[y][x] == BOARD[y+2][x+2]) && (BOARD[y][x] == BOARD[y+3][x+3])) 
               return true;
         }
     }
   
    return false;
  }  

}
