import java.util.List;
import java.util.Random;

public class C4RandomAIPlayer extends Player {

  @Override
  public Integer chooseColumn(List<Integer> availableColumnsToChoose) {
    
    Random generator = new Random();
    int randomIndex = generator.nextInt(availableColumnsToChoose.size()-1);
    return availableColumnsToChoose.get(randomIndex);
  }
}
