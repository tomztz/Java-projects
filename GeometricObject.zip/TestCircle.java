
public class TestCircle {

	Circle testCircle=new Circle(100);
	
	double testPerimeter=testCircle.getPerimeter();
	double testArea=testCircle.getArea();
	
}
