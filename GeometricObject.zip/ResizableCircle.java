
public class ResizableCircle extends Circle implements Resizable {
	
	public ResizableCircle(double radius) {
		super(radius);
	}
	public void resize(int percent) {
		if(percent>=0) {
		radius=radius+radius*percent*0.01;}
		
		else {
			
			radius=radius-radius*Math.abs(percent)*0.01;
		}
		
	}
	

}
