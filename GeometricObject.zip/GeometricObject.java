
interface GeometricObject {
public abstract double getPerimeter();
public abstract double getArea();
}
