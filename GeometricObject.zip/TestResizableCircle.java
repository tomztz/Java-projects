import java.text.DecimalFormat;

public class TestResizableCircle {

	
	public static void main(String[] args) {
		
		
		TestCircle T=new TestCircle();
		
		
		DecimalFormat format = new DecimalFormat("0.##");
	
		System.out.println("Perimeter of the circle is "+format.format(T.testPerimeter));
		System.out.println("Area of the circle is "+format.format(T.testArea));
	
		ResizableCircle Resizedcircle=new ResizableCircle(100);
		Resizedcircle.resize(-10);
		System.out.println("Perimeter of the resized circle is "+format.format(Resizedcircle.getPerimeter()));
		System.out.println("Area of the resized circle is "+format.format(Resizedcircle.getArea()));
	}

}
