import java.util.Scanner;

/* SELF ASSESSMENT 

1. ResolveBet

I have correctly defined ResolveBet which takes the bet type (String) and the Wallet object, and a void return type [Mark out of 7:7 ].
Comment:Yes, it takes a string input and returns nothing so I defined it as "public static void ResolveBet(String type,Wallet wallet)".
My program presents the amount of cash in the wallet and asks the user how much he/she would like to bet [Mark out of 8:8 ].
Comment:Yes,every time before the bet i'll ask the user how much he would like to gamble, and after gambling the amount of
money would be added or subtracted corresponds to his winning/losing.
My program ensures the bet amount is not greater than the cash in the wallet [Mark out of 5:5 ].
Comment:Yes,I used the getCash() method to see the amount of money in the wallet, and if the betting amount entered is greater than that,
a message will be displayed and the function will start again.
My program creates three Dice objects, rolls them and creates a total variable with a summation of the roll values returned [Mark out of 15:15 ]..
Comment:Yes, inside the function I created three Dice objects and I roll them and store the dice value inside different variables to compare later.
My program determines the winnings by comparing the bet type with the total and comparing the bet type with the dice faces for the triple bet [Mark out of 20:20 ].
Comment:Yes, I used two boolean variables one to see if it is a triple, and one to check if the player wins or not, if it's a triple, the user would only win for high 
or low if triple is false, otherwise if the guess matches the range the user will win.

My program outputs the results (win or loss) and adds the winnings to the wallet if user wins or removes the bet amount from the wallet if the user loses [Mark out of 10:10 ].
Comment:Yes, every time the correct amount is added and removed based on the rate in the question and correctly print out.

2. Main

I ask the user for the amount of cash he/she has, create a Wallet object and put this cash into it [Mark out of 15:15 ]
Comment:Yes, at the start of the main method I ask the user how much money he has, and then I used the setCash method in the 
Wallet class to record that money, and the cash will be changed after each betting.
My program loops continuously until the user either enters quit or the cash in the wallet is 0 [Mark out of 5:5 ]
Comment:Yes,I used a do while loop, which will continuously ask the user to gamble, until the money in the wallet is less than or equal to zero.
and it will break the loop when quit is entered.
I ask the user to enter any of the four bet types or quit [Mark out of 5:5 ].
Comment:Yes, every time I ask the user what bet he's going to make, and stored in a string variable.
My program calls resolveBet for each bet type entered [Mark out of 5:5  ].
Comment:Yes, after asking the bet type, I call the function, with the string which is the player's bet and the player's
wallet as parameters.
At the end of the game my program presents a summary message regarding winnings and losses [Mark out of 5:4 ]
Comment:Yes, I printed out the users starting cash and remaining cash, and then I did a subtraction to tell the user how much 
the user win/lose.

 Total Mark out of 100 (Add all the previous marks):99
*/


public class ChuckALuckDiceGame {
	
	
	public static void ResolveBet(String type,Wallet wallet) {
		System.out.println("here is the amount of cash in your wallet "+wallet.getCash());
		System.out.println("Enter the money you want to gamble:");
		Scanner input2= new Scanner(System.in);
		if(!input2.hasNextDouble()) {
			System.out.println("please enter a valid money");
			ResolveBet( type, wallet);
		}
		double betingAmount=input2.nextDouble();
		if(betingAmount<=0) {
			System.out.println("please enter a valid amount i.e positive");
			ResolveBet( type, wallet);
		}
		else if(betingAmount>wallet.getCash()){
			System.out.println("you don't have enough money, go borrow some");
			ResolveBet( type, wallet);
		}
	
		Dice[] dice=new Dice[3];
		for (int i=0;i<dice.length;i++) {
			 dice[i]=new Dice();
			
		}
		dice[0].roll();
		int diceNumber1=0;
		diceNumber1=dice[0].getDiceNumber();
		
		dice[1].roll();
		int diceNumber2=0;
		diceNumber2=dice[1].getDiceNumber();
		
		dice[2].roll();
		int diceNumber3=0;
		diceNumber3=dice[2].getDiceNumber();
		
		boolean win=false;
		boolean triple=false;
		if(diceNumber1==diceNumber2&&diceNumber1==diceNumber3&&diceNumber1!=6&&diceNumber1!=1) {
			triple=true;
		}
		int diceTotal=0;
		diceTotal=diceNumber1+diceNumber2+diceNumber3;
		
		if(type.equals("Triple")) {
			
			if(triple==true) {
				win=true;
			}
			
		}
		else if(type.equals("Field")) {
			
			if(diceTotal>12||diceTotal<8) {
				win=true;
			}
			
		}
		else if(type.equals("High")) {
			if(diceTotal>10&&triple==false) {
				win=true;
			}
			
			
		}
		
		else if(type.equals("low")) {
			if(diceTotal<11&&triple==false) {
				win=true;
			}
		}
		
		if(win==true) {
			System.out.println("you win");
			if(triple==true) {
				double earnMoney=0;
				earnMoney=betingAmount+betingAmount*30;
				wallet.setCash(wallet.getCash()+earnMoney);
			}
			else {
				double earnMoney=0;
				earnMoney=betingAmount+betingAmount;
				wallet.setCash(wallet.getCash()+earnMoney);
			}
		}
		else {
			System.out.println("you lose");
			wallet.setCash(wallet.getCash()-betingAmount);
		}
		
	}

	public static void main(String[] args) {
		
		
		System.out.println("enter the amount of money in your wallet");
		Scanner input = new Scanner(System.in);
		double cashTotal=input.nextDouble();
		if(cashTotal<=0) {
			System.out.println("please enter a valid number");
			System.exit(1);
		}
		Wallet wallet= new Wallet();
		wallet.setCash(cashTotal);
		
		
		
		do {
			System.out.println("Enter the type of bet (Triple,Field,High,Low)or enter quit");
			
			Scanner betInput= new Scanner(System.in);
			
			String typeOfBet=betInput.next();
		
			if(typeOfBet.equals("quit")) {
				break;
			}
			ResolveBet(typeOfBet,wallet);
			
			if(wallet.getCash()>=cashTotal) {
				double newCash=wallet.getCash()-cashTotal;
				System.out.println("you started with � "+cashTotal+" you end up with � "+wallet.getCash()
						+ " you earned �"+newCash+" continue betting to win more");
			}
			else {
				double newCash=cashTotal-wallet.getCash();
				System.out.println("you started with �"+cashTotal+" you end up with �"+wallet.getCash()
					+" you losed �"+newCash+" continue betting to win them back");
			}
			
			
			
		}
		while(wallet.getCash()>0);
		
	}

}
