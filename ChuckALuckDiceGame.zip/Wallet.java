
public class Wallet {
	
	private double cash;
	
	public double getCash() {
		return cash;
	}
	
	public void setCash(double newCash) {
		
		cash=newCash;
		}
	}


