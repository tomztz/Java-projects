import java.util.Random;



public class Dice {
	private static final int DICE_NUMBER=6;

	private int diceNumber;
	
	public int getDiceNumber() {
		return diceNumber;
	}
	
	public void roll() {
		Random r=  new Random();
		diceNumber=r.nextInt(DICE_NUMBER)+1;
		if(diceNumber<=0) {
			roll();
		}
	}
}
